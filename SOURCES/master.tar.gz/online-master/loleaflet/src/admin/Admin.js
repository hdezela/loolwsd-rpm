/* Export variable Admin */

var Admin = {};
module.exports = Admin;
