/* Strings for l10n from evol.colorpicker */
var themeColors = _('Theme Colors');
var standardColors = _('Standard Colors');
var webColors = _('Web Colors');
var backToPalette = _('Back to Palette');
var history = _('History');
var noHistory = _('No history yet.');
